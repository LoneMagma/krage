/** Device-local touch preferences and bounded analogue movement. */
export const TOUCH_DEFAULTS={sensitivity:1,size:1,inset:16};
export function touchPreferences(value:unknown){
 const v=(value&&typeof value==='object'?value:{}) as Record<string,unknown>;
 const number=(key:keyof typeof TOUCH_DEFAULTS,min:number,max:number)=>typeof v[key]==='number'&&Number.isFinite(v[key])?Math.max(min,Math.min(max,v[key] as number)):TOUCH_DEFAULTS[key];
 return {sensitivity:number('sensitivity',.4,2.4),size:number('size',.8,1.3),inset:number('inset',8,64)};
}
export function touchStick(dx:number,dy:number,radius:number){
 const distance=Math.hypot(dx,dy);if(distance<radius*.12)return {right:0,forward:0};
 const strength=Math.min(1,(distance/radius-.12)/.88);
 return {right:dx/distance*strength,forward:-dy/distance*strength};
}
export class MobileResolution {
 ratio=.85;private seconds=0;private frames=0;
 sample(dt:number){
  if(dt<=0||dt>.5)return false;
  this.seconds+=dt;this.frames++;if(this.seconds<3)return false;
  const fps=this.frames/this.seconds,old=this.ratio;
  this.ratio=Math.max(.55,Math.min(1,this.ratio+(fps<45?-.1:fps>57?.05:0)));
  this.frames=this.seconds=0;return Math.abs(old-this.ratio)>.001;
 }
}
