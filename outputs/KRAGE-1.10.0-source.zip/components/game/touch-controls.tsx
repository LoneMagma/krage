'use client';
import {useEffect,useRef,useState,type CSSProperties,type PointerEvent} from 'react';
import {Crosshair,ArrowUp,ArrowDown,ChevronsRight,RotateCcw,Repeat2,SlidersHorizontal,X} from 'lucide-react';
import type {Arena} from '@/lib/game/engine';
import {emptyInput} from '@/lib/game/core';
import {TOUCH_DEFAULTS,touchPreferences,touchStick} from '@/lib/game/touch';
type Action='fire'|'ads'|'jump'|'crouch'|'slide';
export function TouchControls({getArena}:{getArena:()=>Arena}){
 const [prefs,setPrefs]=useState(()=>{try{return touchPreferences(JSON.parse(localStorage.getItem('krage-touch-v1')||'{}'))}catch{return TOUCH_DEFAULTS}}),[editing,setEditing]=useState(false),[gyro,setGyro]=useState(false),[gyroError,setGyroError]=useState(''),[stick,setStick]=useState({x:0,y:0});
 const pointers=useRef(new Map<number,{kind:Action|'look'|'stick';x:number;y:number}>());
 useEffect(()=>{
  const engine=getArena();
  const clear=()=>{pointers.current.clear();engine.touch=emptyInput();setStick({x:0,y:0});};
  window.addEventListener('blur',clear);window.addEventListener('orientationchange',clear);document.addEventListener('visibilitychange',clear);
  return()=>{clear();window.removeEventListener('blur',clear);window.removeEventListener('orientationchange',clear);document.removeEventListener('visibilitychange',clear);};
 },[getArena]);
 useEffect(()=>{
  if(!gyro||editing)return;
  const motion=(e:DeviceMotionEvent)=>{const rate=e.rotationRate;if(!rate)return;const dt=Math.min(.04,(e.interval||16)/1000),angle=(screen.orientation?.angle??90)*Math.PI/180;
   getArena().look(((rate.beta??0)*Math.sin(angle)+(rate.alpha??0)*Math.cos(angle))*dt*4*prefs.sensitivity,(rate.gamma??0)*dt*4*prefs.sensitivity);
  };window.addEventListener('devicemotion',motion);return()=>window.removeEventListener('devicemotion',motion);
 },[gyro,editing,getArena,prefs.sensitivity]);
 async function toggleGyro(){
  if(gyro){setGyro(false);return;}setGyroError('');
  try{if(!window.isSecureContext||!window.DeviceMotionEvent)throw Error('Gyro needs HTTPS and motion support.');
   const api=window.DeviceMotionEvent as typeof DeviceMotionEvent & {requestPermission?:()=>Promise<string>};
   if(api.requestPermission&&await api.requestPermission()!=='granted')throw Error('Motion permission denied.');setGyro(true);
  }catch(e){setGyroError(e instanceof Error?e.message:'Gyro unavailable.');}
 }
 function down(e:PointerEvent<HTMLElement>,kind:Action|'look'|'stick'){
  e.preventDefault();if(editing||[...pointers.current.values()].some(p=>p.kind===kind))return;
  e.currentTarget.setPointerCapture(e.pointerId);pointers.current.set(e.pointerId,{kind,x:e.clientX,y:e.clientY});
  if(kind!=='look'&&kind!=='stick')getArena().touch[kind]=true;
 }
 function move(e:PointerEvent<HTMLElement>){
  const p=pointers.current.get(e.pointerId);if(!p)return;
  const dx=e.clientX-p.x,dy=e.clientY-p.y;
  if(p.kind==='stick'){const value=touchStick(dx,dy,48*prefs.size);Object.assign(getArena().touch,value);setStick({x:value.right*30,y:-value.forward*30});}
  else if(p.kind==='look'||p.kind==='fire'){getArena().look(dx*1.8*prefs.sensitivity,dy*1.8*prefs.sensitivity);p.x=e.clientX;p.y=e.clientY;}
 }
 function end(e:PointerEvent<HTMLElement>){const p=pointers.current.get(e.pointerId);if(!p)return;pointers.current.delete(e.pointerId);
  if(p.kind==='stick'){getArena().touch.forward=getArena().touch.right=0;setStick({x:0,y:0});}else if(p.kind!=='look')getArena().touch[p.kind]=false;
 }
 const icons={fire:<Crosshair/>,ads:<Crosshair/>,jump:<ArrowUp/>,crouch:<ArrowDown/>,slide:<ChevronsRight/>};
 return <div className="mobile-controls" style={{'--touch-size':prefs.size,'--touch-inset':`${prefs.inset}px`} as CSSProperties} onContextMenu={e=>e.preventDefault()}>
  <div className="mobile-look" onPointerDown={e=>down(e,'look')} onPointerMove={e=>move(e)} onPointerUp={e=>end(e)} onPointerCancel={e=>end(e)} onLostPointerCapture={e=>end(e)}/>
  <div className="mobile-stick" aria-label="Movement joystick" onPointerDown={e=>down(e,'stick')} onPointerMove={e=>move(e)} onPointerUp={e=>end(e)} onPointerCancel={e=>end(e)} onLostPointerCapture={e=>end(e)}><i style={{transform:`translate(${stick.x}px,${stick.y}px)`}}/></div>
  <div className="mobile-actions">{(['ads','jump','crouch','slide','fire'] as const).map(action=><button key={action} aria-label={action==='ads'?'Aim / knife stab':action} className={`mobile-${action}`} onPointerDown={e=>down(e,action)} onPointerMove={e=>move(e)} onPointerUp={e=>end(e)} onPointerCancel={e=>end(e)} onLostPointerCapture={e=>end(e)}>{icons[action]}<small>{action==='ads'?'AIM':action.toUpperCase()}</small></button>)}
  <button aria-label="Reload" onPointerDown={e=>{e.preventDefault();getArena().input.reload=true}}><RotateCcw/><small>RELOAD</small></button>
  <button aria-label="Switch weapon" onPointerDown={e=>{e.preventDefault();getArena().input.weapon=getArena().match.player.weapon===3?getArena().match.player.primary:3}}><Repeat2/><small>SWAP</small></button></div>
  <button className="mobile-adjust" aria-label="Touch settings" onClick={()=>{getArena().touch=emptyInput();pointers.current.clear();setStick({x:0,y:0});setEditing(!editing)}}>{editing?<X/>:<SlidersHorizontal/>}</button>
  {editing&&<section className="mobile-settings" aria-label="Touch settings">{(['sensitivity','size','inset'] as const).map(key=><label key={key}>{key==='inset'?'EDGE SPACING':key.toUpperCase()}<input type="range" min={key==='inset'?8:key==='size'?.8:.4} max={key==='inset'?64:key==='size'?1.3:2.4} step={key==='inset'?2:.1} value={prefs[key]} onChange={e=>{const next={...prefs,[key]:Number(e.target.value)};setPrefs(next);try{localStorage.setItem('krage-touch-v1',JSON.stringify(next))}catch{}}}/></label>)}<button aria-pressed={gyro} onClick={()=>void toggleGyro()}>GYRO {gyro?'ON':'OFF'}</button>{gyroError&&<output>{gyroError}</output>}</section>}
 </div>;
}
